"""20 目标 UniSwarm-SSVEP 动态刺激界面。"""

import json
from pathlib import Path

import numpy as np
from psychopy import monitors

from dynamic_content_mapping import DynamicContentMapper
from dynamic_paradigm import dynamic_ssvep_paradigm
from metabci.brainstim.framework import Experiment
from metabci.brainstim.paradigm import SSVEP


def load_config():
    """从脚本所在目录读取配置，避免受启动目录影响。"""
    config_path = Path(__file__).with_name("config.json")
    with open(config_path, "r", encoding="utf-8") as config_file:
        return json.load(config_file)


if __name__ == "__main__":
    config = load_config()
    mapper = DynamicContentMapper(config)

    monitor = monitors.Monitor(
        name="primary_monitor",
        width=59.6,
        distance=60,
        verbose=False,
    )
    monitor.setSizePix([1920, 1080])
    monitor.save()

    experiment = Experiment(
        monitor=monitor,
        bg_color_warm=np.array([-1, -1, -1]),
        screen_id=0,
        win_size=np.array([1440, 960]),
        is_fullscr=False,
        record_frames=False,
        disable_gc=False,
        process_priority="normal",
        use_fbo=False,
    )
    win = experiment.get_window()

    n_elements = int(config["n_elements"])
    rows = int(config["rows"])
    columns = int(config["columns"])
    fps = float(config["fps"])
    stim_time = float(config["stim_time"])

    # 物理刺激编码保持固定；DCMM 只改变文字和编号对应的逻辑语义。
    frequencies = 8.0 + 0.2 * np.arange(n_elements)
    phases = np.asarray([index * 0.35 % 2 for index in range(n_elements)])

    ssvep = SSVEP(win=win)
    ssvep.config_pos(
        n_elements=n_elements,
        rows=rows,
        columns=columns,
        stim_length=100,
        stim_width=100,
    )
    ssvep.config_text(symbols=mapper.labels(), tex_color=[1, 1, 1])
    ssvep.config_color(
        refresh_rate=fps,
        stim_time=stim_time,
        stimtype="sinusoid",
        stim_color=[1, 1, 1],
        stim_opacities=1,
        freqs=frequencies,
        phases=phases,
    )
    ssvep.config_index()
    ssvep.config_response()

    def refresh_labels(labels):
        """原位更新文字；空字符串不会隐藏对应的闪烁刺激块。"""
        ssvep.symbols = list(labels)
        for text_stimulus, label in zip(ssvep.text_stimuli, labels):
            text_stimulus.text = label
            text_stimulus.name = label

    def handle_prediction(predict_index, selected_label):
        """LSL 收到 FBSCCA 类别后执行 DCMM 状态转换并刷新界面。"""
        result = mapper.handle_prediction(predict_index)
        refresh_labels(mapper.labels())
        print(
            "DCMM: id={刺激编号}, label={文字!r}, action={动作}, "
            "interface={当前界面}, scope={控制范围}, group={当前组}, "
            "vehicle={当前车辆}, gear={当前挡位}".format(**result)
        )

    experiment.register_paradigm(
        "进入操控界面",
        dynamic_ssvep_paradigm,
        VSObject=ssvep,
        bg_color=np.array([-1, -1, -1]),
        display_time=1,
        index_time=2,
        rest_time=0.5,
        response_time=1,
        port_addr="COM12",
        nrep=2,
        pdim="ssvep",
        lsl_source_id="meta_online_worker",
        online=False,
        device_type="Neuracle",
        prediction_handler=handle_prediction,
        prediction_timeout=5.0,
    )

    experiment.run()
